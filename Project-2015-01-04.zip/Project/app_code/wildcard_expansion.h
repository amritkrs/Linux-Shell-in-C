#include<wordexp.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void wildcard_exp(char ***argv,int *argc);
int check_wildcard(int argc,char **argv);
int check_wild(char a[]);

