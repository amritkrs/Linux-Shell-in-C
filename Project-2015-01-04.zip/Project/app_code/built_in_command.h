#define __built_in__
void cd(char *path);
int func_built_in_cmd(char *argv[]);
