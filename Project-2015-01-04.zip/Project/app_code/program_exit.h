#define __program_exit__

void pr_exit(int status);

