#include<stdio.h>
void help(char a[]);
void help_pipe(void);
void help_background(void);
void help_redirection(void);
void help_variable(void);
void help_script(void);
void help_wildcard(void);
