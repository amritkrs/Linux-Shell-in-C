#define _Background_
int check_backgrounding(char **argv);
void parse_backgrounding(char ***b_argv,char **argv,int *tmp_argc);
void background(char **argv);
